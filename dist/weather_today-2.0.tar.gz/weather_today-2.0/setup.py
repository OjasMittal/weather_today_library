from setuptools import setup

setup(
    name='weather_today',
    version='2.0',
    packages=[''],
    url='',
    license='MIT',
    author='Ojas Mittal',
    author_email='ojasfarm31@gmail.com',
    description='weather app'
)
